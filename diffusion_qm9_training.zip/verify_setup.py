"""One command that tells you whether this package is ready to train.

    python verify_setup.py                # auto-detects which family is present
    python verify_setup.py --family fm    # or force it

Runs six checks in order and stops at the first failure with a specific reason
and the command that fixes it. Nothing here trains a real model; the whole thing
takes about two minutes.

  1  environment    python, torch, CUDA, rdkit
  2  data           qm9.pt exists, with the exact expected counts and splits
  3  architecture   12 symmetry/gradient checks on the shared network, plus
                    15 exact algebraic identities of the training objective
  4  smoke train    2 epochs on a tiny subset; loss must fall
  5  sampler        guidance and solver correctness, 9 checks
  6  throughput     measured seconds/epoch on THIS machine, with a projection

Exit code 0 means ready. Anything else means stop and read the message.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
OK, BAD = "  [ok]  ", "  [FAIL] "


def hdr(n, title):
    print("\n%s\n%d. %s\n%s" % ("-" * 66, n, title, "-" * 66))


def fail(msg, fix=None):
    print(BAD + msg)
    if fix:
        print("\n  Fix:\n    " + fix.replace("\n", "\n    "))
    sys.exit(1)


def run(cmd, timeout=900):
    p = subprocess.run([sys.executable] + cmd, cwd=HERE, capture_output=True,
                       text=True, timeout=timeout)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--family", choices=["fm", "diffusion", "auto"], default="auto")
    ap.add_argument("--skip-throughput", action="store_true")
    args = ap.parse_args()

    fam = args.family
    if fam == "auto":
        has_fm = os.path.exists(os.path.join(HERE, "proj1/scripts/train_fm.py"))
        has_df = os.path.exists(os.path.join(HERE, "proj1/scripts/train_diffusion.py"))
        fam = "fm" if has_fm else ("diffusion" if has_df else None)
        if fam is None:
            fail("no trainer found in proj1/scripts/")
    script = "proj1/scripts/train_%s.py" % ("fm" if fam == "fm" else "diffusion")
    tag = "verify_%s" % fam
    print("verifying the %s package" % ("FLOW MATCHING" if fam == "fm" else "VP DIFFUSION"))

    # ---------------------------------------------------------------- 1
    hdr(1, "environment")
    print("  python  %s" % sys.version.split()[0])
    if sys.version_info < (3, 10):
        fail("python 3.10+ required")
    try:
        import torch
    except ImportError:
        fail("pytorch not installed",
             "pip install torch --index-url https://download.pytorch.org/whl/cu128")
    print("  torch   %s   cuda build %s" % (torch.__version__, torch.version.cuda))
    if torch.cuda.is_available():
        p = torch.cuda.get_device_properties(0)
        print(OK + "GPU: %s, %.0f GB, capability %d.%d"
              % (p.name, p.total_memory / 1e9, p.major, p.minor))
    else:
        print("  [warn] no CUDA. Training on CPU is ~50x slower and not viable "
              "for the real run.")
    try:
        import rdkit  # noqa: F401
        print(OK + "rdkit present")
    except ImportError:
        fail("rdkit not installed (needed for data prep and validity metrics)",
             "pip install rdkit")

    # ---------------------------------------------------------------- 2
    hdr(2, "data")
    dp = os.path.join(HERE, "data", "qm9.pt")
    if not os.path.exists(dp):
        fail("data/qm9.pt missing",
             "cd data\n"
             "curl -L -o gdb9.tar.gz https://deepchemdata.s3.us-west-1.amazonaws.com/datasets/gdb9.tar.gz\n"
             "tar xzf gdb9.tar.gz\n"
             "cd ..\n"
             "python proj1/scripts/prepare_qm9.py")
    d = torch.load(dp, weights_only=False)
    n = d["coords"].shape[0]
    sizes = {k: len(v) for k, v in d["split"].items()}
    want_n, want = 133885, {"train_a": 51527, "train_b": 51527,
                            "val": 17748, "test": 13083}
    print("  molecules      %d  (expected %d)" % (n, want_n))
    print("  splits         %s" % sizes)
    print("  properties     %s" % d["props"])
    if n != want_n or sizes != want:
        fail("data does not match the expected split -- a checkpoint trained on "
             "this would not compose with the rest of the project",
             "delete data/qm9.pt and re-run prepare_qm9.py WITHOUT changing its seed")
    print(OK + "counts and splits exact")

    # The protocol is: generator + f_A on train_a, f_B on train_b ALONE.
    # This was broken once and cost a day of compute, so it is checked here too.
    import re as _re
    src = open(os.path.join(HERE, script), encoding="utf-8").read()
    m = _re.search(r'"--split",\s*default="([a-z_]+)"', src)
    if not m:
        fail("could not read the --split default from the trainer")
    if m.group(1) != "train_a":
        fail("the trainer defaults to --split %s, but the protocol is train_a "
             "(generator and guide share train_a; the evaluator gets train_b alone)"
             % m.group(1),
             "see SPLIT_PROTOCOL.md; do not train until this is train_a")
    print(OK + "split protocol: generator trains on train_a (51,527)")

    # ---------------------------------------------------------------- 3
    hdr(3, "architecture and objective identities (12 + 15 checks)")
    rc, out = run(["proj1/tests/test_egnn_symmetry.py"])
    tail = [l for l in out.strip().splitlines() if l.strip()][-3:]
    for l in tail:
        print("  " + l)
    if rc != 0 or "ALL PASS" not in out:
        fail("symmetry checks failed -- do not train until this passes",
             "the network was modified; restore proj1/src/models/egnn.py from the package")
    print(OK + "rotation, translation, permutation, padding, finite gradients")

    ti = os.path.join(HERE, "proj1/tests/test_identities.py")
    if os.path.exists(ti):
        rc, out = run(["proj1/tests/test_identities.py"])
        tail = [l for l in out.strip().splitlines() if l.strip()][-2:]
        for l in tail:
            print("  " + l)
        if rc != 0 or "ALL PASS" not in out:
            fail("objective identities failed -- a sign or scaling error in the "
                 "interpolant, the VP schedule or the posterior proxy",
                 "restore proj1/src/diffusion.py and proj1/src/guidance.py from the package")
        print(OK + "interpolant, VP schedule, posterior proxies, masking, zero-CoM")
    else:
        print("  (identity checks not in this package; skipped)")

    # ---------------------------------------------------------------- 4
    hdr(4, "smoke train (2 epochs, tiny subset)")
    rc, out = run([script, "--epochs", "2", "--limit", "2000", "--tag", tag,
                   "--eval-every", "1", "--stab-every", "99", "--hidden", "32",
                   "--layers", "2", "--fresh"])
    lines = [l for l in out.splitlines() if l.strip().startswith("ep ")]
    for l in lines:
        print("  " + l.strip())
    if rc != 0 or len(lines) < 2:
        print(out[-1500:])
        fail("smoke train did not complete")
    def loss_of(line):
        return float(line.split("train")[1].split("(")[0])
    if not (loss_of(lines[1]) < loss_of(lines[0])):
        fail("loss did not decrease over two epochs")
    print(OK + "loss decreasing")
    for suf in (".pt", "_last.pt", "_last_prev.pt", "_prev.pt",
                "_history.json", "_history_prev.json"):
        f = os.path.join(HERE, "proj1", "checkpoints", tag + suf)
        if os.path.exists(f):
            os.remove(f)

    # ---------------------------------------------------------------- 5
    hdr(5, "sampler and guidance correctness (9 checks)")
    tf = os.path.join(HERE, "proj1/tests/test_guidance.py")
    if os.path.exists(tf):
        rc, out = run(["proj1/tests/test_guidance.py"])
        tail = [l for l in out.strip().splitlines() if l.strip()][-3:]
        for l in tail:
            print("  " + l)
        if rc != 0 or "ALL PASS" not in out:
            fail("guidance/solver checks failed")
        print(OK + "call accounting, affine limit, estimators, Euler/Heun orders")
    else:
        print("  (not in this package; skipped)")

    # ---------------------------------------------------------------- 6
    if not args.skip_throughput:
        hdr(6, "throughput on this machine")
        if not torch.cuda.is_available():
            print("  skipped: no GPU")
        else:
            # Time TWO subset sizes and take the SLOPE. A single timing would
            # include fixed costs -- interpreter start, a 142 MB torch.load,
            # CUDA init, and the epoch-1 validation and stability passes, which
            # fire regardless of --eval-every -- and multiplying all of that by
            # scaling by (train size)/limit inflates the estimate several-fold.
            sizes, times = (8000, 24000), []
            for n in sizes:
                t0 = time.time()
                rc, out = run([script, "--epochs", "1", "--limit", str(n), "--tag",
                               "%s_t%d" % (tag, n), "--eval-every", "99",
                               "--stab-every", "99", "--fresh"])
                times.append(time.time() - t0)
                if rc != 0:
                    print(out[-1200:])
                    fail("timing run failed")
                for suf in (".pt", "_last.pt", "_last_prev.pt", "_history.json"):
                    f = os.path.join(HERE, "proj1", "checkpoints",
                                     "%s_t%d%s" % (tag, n, suf))
                    if os.path.exists(f):
                        os.remove(f)
            per_mol = (times[1] - times[0]) / (sizes[1] - sizes[0])
            fixed = times[0] - per_mol * sizes[0]
            N_TRAIN = 51527          # train_a -- the split we actually train on
            per_epoch = per_mol * N_TRAIN
            print("  %d molecules: %.1f s      %d molecules: %.1f s"
                  % (sizes[0], times[0], sizes[1], times[1]))
            print("  fixed overhead per invocation: %.1f s  (excluded from the estimate)"
                  % max(fixed, 0.0))
            print("  -> %.0f s/epoch on train_a (%d molecules)" % (per_epoch, N_TRAIN))
            for n_ep in (1000, 1500, 2000):
                print("     %4d epochs ~ %.1f hours" % (n_ep, per_epoch * n_ep / 3600))
            print("  (our own runs: ~30 s/epoch on train_a, RTX 5080)")
            if per_epoch > 90:
                print("  [warn] that is well above the reference. Check nothing else is "
                      "using the GPU before committing to the long run.")

    print("\n" + "=" * 66)
    print("READY. Start the real run with:")
    print("""
  python -u %s --epochs 1500 --batch 256 \\
      --hidden 256 --layers 8 --split train_a --tag %s --resume 2>&1 | tee %s.log
""" % (script, "fm" if fam == "fm" else "diff", "fm" if fam == "fm" else "diff"))
    print("Watch atom_stab, not the loss. See README_FIRST.md section 'What to watch'.")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
