# Brief for an assisting agent

Written for a coding assistant helping to run this package. A human-facing version of the
same material is in `README_FIRST.md`; this file states the task, the invariants, and the
failure modes compactly. Read both before changing anything.

## Task

Train one generative model on QM9 to convergence and return the checkpoint. **No research
decisions are being delegated** — the architecture, data split, hyperparameters and selection
rule are all fixed upstream and must not be changed. The job is to run it, watch it, and
report honestly.

## Hard invariants — changing any of these makes the result unusable

| Invariant | Why |
|---|---|
| `prepare_qm9.py` seed `20260917` | fixes the four-way split; another seed silently produces different data and the checkpoint will not compose with the rest of the project |
| `proj1/src/models/egnn.py` byte-identical | shared architecture across every model in the project |
| `--split train_a` | 51,527 molecules. The generator must NOT see `train_b` -- that is the evaluator's training data, and a generator that has seen it yields samples the evaluator scores optimistically. Pre-registered. |
| `--hidden 256 --layers 8 --batch 256` | comparability across the two model families |
| selection on `atom_stab`, not loss | pre-registered; see below |

If something appears wrong, **report it rather than fixing it locally.** A silent local fix
that diverges from the other family is worse than a bug we both know about.

## Why selection is on atom stability, not validation loss

Validation loss for these objectives is dominated by irreducible noise at high corruption
levels, so it keeps improving while sample quality does not, and it **cannot resolve the
~0.1 Angstrom precision that decides whether a bond is recognised**. The trainer therefore
samples 512 molecules every 25 epochs, measures the fraction of atoms whose inferred valency
is correct, and keeps the checkpoint with the best value, ties broken on loss.

Expect `val` and `atom_stab` to disagree about which epoch is best. That is the point, and
`atom_stab` wins.

## The metric that matters, and how it compounds

An atom is stable when its inferred valency (from interatomic distances, using the standard
QM9 bond tables) matches its element. A molecule is stable only when **every** atom is, so
over ~18 atoms per molecule:

| atom stability | molecule stability |
|---|---|
| 0.88 | 0.10 |
| 0.92 | 0.22 |
| 0.95 | 0.40 |
| 0.97 | 0.58 |
| 0.987 (published EDM) | 0.79 |

**The 0.987 row is E(3)-EDM's *unconditional* figure from a model trained on ~100k
molecules.** This package trains on 51,527, so it is a reference point for how the metric
compounds, **not a target**. `SPLIT_PROTOCOL.md` explains why, and retracts an earlier
draft that set 0.97 as the goal on the strength of that number.

Small gains in `atom_stab` matter enormously. 0.92 to 0.95 nearly doubles molecule stability.

## Procedure

1. `python verify_setup.py` — six checks, ~2 minutes. **Do not start the real run until this
   exits 0.** It prints the exact command to use, with a measured seconds/epoch for this
   machine.
2. Start the run it prints. Use `tee` so the log survives.
3. If the machine has a wall-clock limit, add `--max-minutes N` (stops cleanly before the
   limit) and re-run the same command with `--resume` to continue. Optimiser, EMA and RNG
   state are all restored.
4. Report at roughly epoch 300 with the recent log lines, so the trajectory can be checked
   early rather than at hour 20.

## Reading the log

```
ep  250  train 1.81 (c 1.65 f 0.16)  val 1.81  atom_stab 0.9163  mol_stab 0.2075  <- best  (7412s)
```

- `train` / `val` — the regression objective. Falls fast then plateaus; **not** the target.
- `c` / `f` — coordinate and atom-type components. Coordinates are the slow half and are what
  bond inference depends on.
- `atom_stab` / `mol_stab` — sampled quality, every `--stab-every` epochs. **This is the signal.**
- `<- best` — this checkpoint was written to `<tag>.pt`.
- `(7412s)` — **cumulative** seconds since this process started, not this epoch's
  time, and it resets to 0 on every `--resume`. For seconds/epoch, subtract two
  consecutive lines from the same process.

## Known failure modes

| Symptom | Meaning |
|---|---|
| loss becomes `nan` immediately | a `sqrt(0)` in the coordinate update, if `egnn.py` was modified. `test_egnn_symmetry.py` catches it — check 12 exists for this reason. |
| `atom_stab` stuck near 0.0 after 100+ epochs | not undertrained — something structural. Send the log. |
| resume raises `--resume: hidden was X, now Y` | the guard working as intended: it refuses to continue across a config change that would mix two different models. Either restore the config or start fresh with `--fresh`. |
| `val` improving while `atom_stab` is flat | normal and expected. Trust `atom_stab`. |
| jobs finish in 0 seconds | the epoch budget was already reached. Raising `--epochs` mid-run **rebuilds the cosine schedule and jumps the LR back up** (it prints a NOTE, and PyTorch may warn about `lr_scheduler.step()` ordering -- both are expected on that path). If only one family does this the two no longer share a schedule, so report it rather than doing it silently. |

## Do not

- Run heavy training on a shared login node.
- Use `CUDA_VISIBLE_DEVICES=""` to force CPU — it does not hide the GPU from PyTorch on
  Windows. Use `--device cpu`.
- Delete `<tag>_last.pt`; it is the resume state. `<tag>.pt` is the best-so-far model and is
  what gets returned.
- Change the property normalisation or the atom-type ordering.

## Return

`proj1/checkpoints/<tag>.pt`, `<tag>_history.json`, the full log, and a one-line summary:
epoch reached, best `atom_stab`, best `mol_stab`, seconds/epoch.

The final line of training prints all three for the SELECTED checkpoint, and
`<tag>_history.json` carries `best_atom_stability` / `best_mol_stability`.

**For a number to quote, use `python inspect_checkpoint.py proj1/checkpoints/<tag>.pt`**
rather than the training log. It re-samples on a fresh seed; the trainer picks the best
of many evaluations on one fixed sample, so its figure is optimistic by roughly one to
two standard errors. The same tool diagnoses a run that looks wrong -- point it at a
mid-run `_last.pt`.

`SPLIT_PROTOCOL.md` explains why the generator trains on `train_a` and what breaks if it
does not. Read it before changing `--split`.
