Data goes here. Run:
  cd data && curl -L -o gdb9.tar.gz https://deepchemdata.s3.us-west-1.amazonaws.com/datasets/gdb9.tar.gz && tar xzf gdb9.tar.gz && cd ..
  python proj1/scripts/prepare_qm9.py
