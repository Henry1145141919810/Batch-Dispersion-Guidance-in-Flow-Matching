"""Look at a checkpoint: sample molecules, score them, print examples.

    python inspect_checkpoint.py proj1/checkpoints/fm.pt
    python inspect_checkpoint.py proj1/checkpoints/fm_last.pt --n 256 --steps 100
    python inspect_checkpoint.py proj1/checkpoints/fm_ep0500.pt --smiles 10

Use this when a run looks wrong and you want to know WHAT is wrong rather than
sending a log and waiting. It works on any checkpoint the trainer writes,
including `_last.pt` mid-run and the periodic `_epNNNN.pt` snapshots. The model
family is read from the checkpoint; it is never guessed, because sampling a
diffusion model through the flow ODE (or the reverse) yields a plausible-looking
number that is meaningless and nothing downstream would catch it.

It re-measures stability on a FRESH sample with a different seed from the one
training used. That matters: the trainer selects the best of ~60 evaluations on
one fixed sample, so its reported best is biased upward by roughly one to two
standard errors -- the winner's curse. **Quote the number from here, not the
one in the training log.**

Reading the output:

  atom stability   fraction of atoms whose inferred valency matches their element
  mol stability    fraction of molecules where EVERY atom is correct
  validity         RDKit can sanitise the inferred bond graph
  connected        of those, the fraction that are a single connected molecule
                   rather than unbonded fragments -- read it WITH validity, which
                   is 1.0 for an untrained model whose atoms are too far apart
                   to bond at all
  uniqueness       distinct canonical SMILES among the valid ones

Real QM9 measured through this same code gives atom 0.9935, molecule 0.9507,
validity 0.975 -- that is the ceiling, not 1.0, because bonds are inferred from
distances.
"""
from __future__ import annotations

import argparse
import os
import sys
import time

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "proj1", "src"))
from models.egnn import EGNNVelocity  # noqa: E402
from evaluation import stability, to_smiles  # noqa: E402
from sampling import FlowSampler, VPSampler, initial_noise, integrate  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("checkpoint")
    ap.add_argument("--n", type=int, default=256, help="molecules to sample")
    ap.add_argument("--steps", type=int, default=100, help="NFE")
    ap.add_argument("--solver", default="euler", choices=["euler", "heun"])
    ap.add_argument("--seed", type=int, default=99991,
                    help="deliberately NOT the trainer's 4321, so this is a fresh sample")
    ap.add_argument("--smiles", type=int, default=5, help="example SMILES to print")
    ap.add_argument("--raw", action="store_true",
                    help="use the raw weights instead of the EMA copy (EMA is what "
                         "training selects on, so the default is the right comparison)")
    ap.add_argument("--family", default=None, choices=["flow", "vp_diffusion"],
                    help="only needed for checkpoints that predate the family key")
    ap.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    args = ap.parse_args()

    dev = ("cuda" if torch.cuda.is_available() else "cpu") if args.device == "auto" else args.device
    ck = torch.load(args.checkpoint, map_location="cpu", weights_only=False)

    # `_last.pt` (resume state) and `<tag>.pt` (deliverable) have different keys
    is_last = "model" in ck and "state_dict" not in ck
    sd = ck["ema" if (is_last and not args.raw) else
            ("model" if is_last else ("ema_state_dict" if not args.raw else "state_dict"))]
    cargs = ck["args"]
    # Never guess. Sampling a diffusion model through the flow ODE (or vice
    # versa) produces a plausible-looking number that is meaningless, and
    # nothing downstream would flag it. Older checkpoints predating the family
    # key must be named explicitly.
    family = ck.get("family") or cargs.get("family")
    if family is None:
        family = args.family
    if family is None:
        raise SystemExit(
            "this checkpoint records no 'family' key, so the sampler cannot be "
            "chosen safely. Re-run with --family flow or --family vp_diffusion. "
            "(Checkpoints written before 19 Sep lack this key.)")
    if family not in ("flow", "vp_diffusion"):
        raise SystemExit("unknown family %r" % family)

    print("checkpoint : %s" % args.checkpoint)
    kind = ("resume state (_last.pt)" if is_last else
            ("periodic snapshot" if "_ep" in os.path.basename(args.checkpoint)
             else "selected best"))
    print("  kind     : %s" % kind)
    print("  family   : %s" % family)
    print("  epoch    : %s" % ck.get("epoch", "?"))
    print("  weights  : %s" % ("raw" if args.raw else "EMA"))
    for k in ("atom_stability", "mol_stability", "val_loss"):
        if k in ck and ck[k] == ck[k]:
            print("  %-16s : %.4f   (as recorded during training)" % (k, ck[k]))
    print("  config   : hidden %s, layers %s, split %s, batch %s, lr %s"
          % (cargs.get("hidden"), cargs.get("layers"), cargs.get("split"),
             cargs.get("batch"), cargs.get("lr")))

    # The VP time grid stops at tau_min, and training evaluated stability on the
    # grid the trainer used. Taking the sampler default instead would silently
    # score the model on a different grid the moment the trainer's TAU_MIN moved
    # -- the same failure as guessing the family, just quieter.
    tau_min = None
    if family == "vp_diffusion":
        tau_min = ck.get("tau_min")
        if tau_min is None:
            tau_min = 1e-3
            print("  tau_min  : %g (ASSUMED -- this checkpoint does not record it, "
                  "so if the trainer's TAU_MIN was changed this number is not "
                  "comparable to the training log)" % tau_min)
        else:
            print("  tau_min  : %g (from the checkpoint)" % tau_min)

    d = torch.load(os.path.join(HERE, "data", "qm9.pt"), weights_only=False)
    types = d["types"]
    net = EGNNVelocity(len(types), cargs["hidden"], cargs["layers"])
    net.load_state_dict(sd)
    net = net.to(dev).eval()
    for p in net.parameters():
        p.requires_grad_(False)

    print("\nsampling %d molecules at NFE %d (%s), seed %d ..."
          % (args.n, args.steps, args.solver, args.seed))
    t0 = time.time()
    g = torch.Generator(device=dev).manual_seed(args.seed)
    sel = d["split"]["val"][: args.n]
    mask_all = d["mask"][sel].to(dev)
    cs, fs = [], []
    for i in range(0, args.n, 128):
        m = mask_all[i:i + 128]
        c0, f0 = initial_noise(m, len(types), g)
        smp = (VPSampler(net, m, tau_min=tau_min) if family == "vp_diffusion"
               else FlowSampler(net, m))
        c, f, _ = integrate(smp, c0, f0, args.steps, args.solver)
        cs.append(c.cpu())
        fs.append(f.cpu())
    C, F, M = torch.cat(cs), torch.cat(fs), mask_all.cpu()
    el = time.time() - t0

    finite = torch.isfinite(C).all((1, 2)) & torch.isfinite(F).all((1, 2))
    n_bad = int((~finite).sum())
    C = torch.where(finite.view(-1, 1, 1), C, torch.zeros_like(C))
    F = torch.where(finite.view(-1, 1, 1), F, torch.zeros_like(F))

    st = stability(C.float(), F.float(), M.float(), types)
    n_at = sum(s[1] for s in st)
    n_sa = sum(s[0] for s, ok in zip(st, finite) if ok)
    n_sm = sum(1 for s, ok in zip(st, finite) if ok and s[2])
    smi = [to_smiles(s[3], s[4]) if ok else None for s, ok in zip(st, finite)]
    valid = [x for x in smi if x is not None]

    a = n_sa / max(n_at, 1)
    m_ = n_sm / max(len(st), 1)
    print("  %.1f s  (%.0f ms/molecule)\n" % (el, 1000 * el / args.n))
    print("  %-22s %.4f      (real QM9: 0.9935)" % ("atom stability", a))
    print("  %-22s %.4f      (real QM9: 0.9507)" % ("molecule stability", m_))
    print("  %-22s %.4f      (real QM9: 0.975)" % ("validity", len(valid) / len(st)))
    # Validity alone is a trap early on: a cloud of atoms too far apart to bond
    # yields no bonds, and RDKit sanitises "C.F.F.O..." perfectly happily, so an
    # untrained model scores validity 1.0. Connectivity is what distinguishes a
    # molecule from a bag of atoms.
    conn = [x for x in valid if "." not in x]
    print("  %-22s %.4f      (of the valid ones, how many are a SINGLE"
          % ("connected", len(conn) / max(len(valid), 1)))
    print("  %-22s               connected molecule rather than loose atoms)" % "")
    print("  %-22s %.4f" % ("uniqueness of valid", len(set(valid)) / max(len(valid), 1)))
    if n_bad:
        print("  %-22s %d of %d   <- trajectories diverged" % ("NON-FINITE", n_bad, args.n))

    print("\n  atom stability implies molecule stability ~%.4f if atoms were "
          "independent;\n  the measured %.4f differs because errors cluster within a molecule."
          % (a ** 18, m_))

    if args.smiles and valid:
        print("\n  example molecules:")
        for x in valid[:args.smiles]:
            print("    " + x)
    elif args.smiles:
        print("\n  no valid molecules to show -- the model is not yet producing "
              "sanitisable structures.")

    print("\n  diagnosis:")
    if n_bad > args.n * 0.05:
        print("    Trajectories are diverging. This is not undertraining; report it.")
    elif valid and len(conn) / len(valid) < 0.5 and a < 0.9:
        print("    Mostly disconnected atoms, not molecules -- the high validity")
        print("    above is an artefact of there being no bonds to get wrong.")
        print("    Normal very early in training; structural if it persists.")
    elif a < 0.5:
        print("    Very early in training, or something structural is wrong. If this")
        print("    is past epoch ~100, send the log rather than continuing.")
    elif a < 0.90:
        print("    Training normally, not yet converged. Keep going.")
    else:
        print("    Good progress. There is no fixed target: see SPLIT_PROTOCOL.md, which")
        print("    retracts the 0.97 figure as being set against a full-data baseline")
        print("    rather than the half-data setting this package trains in.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
