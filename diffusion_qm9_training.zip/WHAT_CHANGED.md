# Revision history for this package

**If you received an earlier copy, discard it.** Defects were found and fixed on 19 September
across two adversarial review passes. Several change *which model you end up with*, and one
could lose an entire run. An older package would reproduce all of them.

This file exists so you can see what was wrong rather than taking "use the new one" on trust.

---

## How they were found

The first full training run finished 150 epochs and produced a model with **16% molecule
stability** against a ~95% ceiling on real QM9 data. That prompted a line-by-line review of the
trainer rather than more training, followed by an independent adversarial review of the whole
package. Every defect below was reproduced in code before being fixed, and the fix verified after.

---

## The defects

### 1. The evaluation loop rewound the training noise stream

`evaluate()` called `torch.manual_seed(1234 + k)` to make validation reproducible. That seeds the
**global** generator — the same one the training loop draws `t` and `eps` from. Every
`--eval-every` epochs the corruption sequence restarted, so the model saw the same noise
realisations repeatedly instead of fresh ones.

**Fix:** wrap the eval loop in `torch.random.fork_rng`, restoring global state afterwards.
**Verified:** with the bug, "epoch 2" draws differ from an uninterrupted run; with the fix they
match exactly.

### 2. The checkpoint was selected by validation loss

The most consequential one. Validation loss for these objectives is dominated by irreducible noise
at high corruption and **cannot resolve the ~0.1 Angstrom precision that decides whether a bond is
recognised**. It keeps improving while sample quality does not.

The project had already *pre-registered* the correct rule — highest validation atom stability at
NFE 100, ties broken by loss — and the trainer simply didn't implement it.

**Fix:** sample 512 molecules every 25 epochs, measure atom stability, select on that.
**Verified:** a smoke run kept epoch 2 over epoch 3 *despite* epoch 3 having lower loss.

### 3. The learning rate decayed to zero before convergence

`CosineAnnealingLR` with `T_max=150` reaches ~0 at epoch 150, so the last ~50 epochs ran below 10%
of the initial rate on a model nowhere near converged. The loss curve flattened, which looked like
convergence and was actually the schedule switching learning off.

**Fix:** `eta_min = 0.05 * lr` floor, and `T_max` set to the real total.

### 4. EMA decay was far too short

0.999 is a ~1,000-step horizon; the full run is several hundred thousand steps, so the EMA was
averaging over the most recent fraction of a percent of training. **The EMA copy is what gets
sampled and saved**, so this directly degraded the returned model.

**Fix:** 0.9999 (EDM's value) with warmup `min(ema, (1+t)/(10+t))`, so early epochs aren't frozen
at the random initialisation.

### 5. A relaunch could destroy the best checkpoint

`--fresh` was declared and **never read**. `best` was seeded only from `<tag>_last.pt`, and only
inside the resume branch — `<tag>.pt`, the actual deliverable, was never consulted. So a forgotten
`--resume`, a deleted `_last.pt`, or a quota purge meant the first evaluation always looked like an
improvement and overwrote a good model with a one-epoch one.

**Fix:** seed from `<tag>.pt` whenever it exists, unless `--fresh` is passed — and `--fresh` now
actually does something. **Verified:** the good checkpoint survives both attack paths, and
`--fresh` still overrides.

### 6. Checkpoint writes were not atomic

`torch.save` wrote ~60 MB in place every epoch. A SIGTERM landing inside that write leaves a
truncated archive torch cannot read at all, and the natural recovery — restart — then destroyed
the best checkpoint via defect 5. One ill-timed signal could lose the whole run.

**Fix:** write to a temp file then `os.replace` (atomic on POSIX and Windows), plus one rotating
backup. A second review caught that the first attempt covered the resume state but **not the
deliverable checkpoint**, and that the new guard would then refuse to start at all on a corrupt
file. Both are fixed: every checkpoint and the history file are written atomically, and an
unreadable checkpoint now falls back to the backup with a message instead of crashing.

### 7. The setup script over-stated run time

It timed a whole subprocess — interpreter start, a 142 MB load, CUDA init, and the epoch-1
validation and stability passes — then scaled all of it by the subset ratio. Fixed costs don't
scale, so they were inflated ~8x. A recipient on a perfectly good GPU would have been told they
were 4x slower than the reference.

**Fix:** time two subset sizes and take the **slope**, which cancels fixed costs. A second review
then caught that the slope was still being multiplied by 103,054 (the full pool) rather than
51,527 (the split actually trained on), roughly doubling the figure again. Both are now fixed and
the estimate was checked against a directly measured epoch.

### 8. The two trainers were not identical

The flow-matching trainer saved periodic epoch snapshots; the diffusion one did not. And only the
diffusion checkpoint carried a `family` key. Since the whole point is comparing the two families,
any asymmetry in saving or logging is a defect: one family would have come back with the ability to
re-evaluate at other NFEs and reconstruct a stability-versus-epoch curve, and the other without.

**Fix:** both now have `--save-every`, both write `family`, their option names match exactly,
and the save order and metric-binding scope were aligned after a second review found the
diffusion trainer could stamp a snapshot with a previous epoch's metrics.

### 9. Checkpoint selection could be seeded across a config change

The `--resume` guard refuses to continue a run whose `--split`, `--hidden` or `--layers` differ
from the checkpoint's. Selection had no such check: it seeds `best_stab` from an existing
`<tag>.pt` so that a relaunch cannot overwrite a good model with a one-epoch one (defect 5).

Together those leave a gap. Point a **correct** run at a directory holding a checkpoint from a
**different** configuration and the new run inherits the old score. The old model was trained on
different data, so that score is not comparable; the new run may never beat it, never write a
deliverable, and leave the old model on disk under the filename you will later ship.

**Fix:** selection now refuses a `<tag>.pt` whose `split`, `hidden` or `layers` disagree with the
current run, exits non-zero so a scheduler sees the failure, and names the mismatch. `--fresh`
remains the deliberate override. **Verified:** a `train_ab` checkpoint blocks a `train_a` run
with an explicit message, and `--fresh` starts selection over.

---

## What did *not* change

The mathematics was correct and is untouched: the architecture, the interpolant and VP schedule,
zero centre-of-mass handling, masking, and the evaluation metrics.

An independent reviewer checked the bond tables against EDM's `bond_analyze.py` and found one
missing triple-bond entry (C-O at 113 pm). On real QM9 it made no difference (no pair falls in
that window), which is why it was first left alone. A later audit of **generated** samples found
~2.5% of molecules do have such a pair, and the missing entry inflated atom stability by ~0.2
points and validity by ~1.1 points relative to EDM's own code. **The entry is now present**
(`proj1/src/evaluation.py`, 20 Sep) and the table matches EDM's entry for entry, verified by a
brute-force grid. Effect on checkpoint *selection* is immaterial (differences of ~0.2 points are
below the 512-sample noise), so a run started with the earlier table does not need restarting.

The same reviewer independently confirmed both samplers are numerically sound and comparably
resolved at NFE 100 — on an analytically exact field both land on the target to machine precision,
and on a non-degenerate Gaussian both show ~1-3% error at NFE 100. **Neither family is
disadvantaged by the shared sampling settings.**

So this was plumbing around correct mathematics, not a redesign.

---

## One more change, and it is a research decision rather than a bug

An earlier version of this package trained the generator on **both** data halves (103,054
molecules). That was wrong, and it is now `--split train_a` (51,527).

The second half trains the *evaluator*. A generator that has seen those molecules produces samples
the evaluator scores optimistically — a leak that biases every downstream number. The cost is
real and we disclose it: 50k where E(3)-EDM uses 100k. TFG-Flow and PropMolFlow use the same
50/50, so our numbers stay comparable to theirs.

**Consequence: checkpoints from the earlier package cannot be resumed into this one.** Different
data and a different selection criterion. Start fresh; the resume guard will refuse a mismatched
config rather than silently mixing two regimes.

---

## What you will see that the old package didn't show

```
ep  250  train 1.81 (c 1.65 f 0.16)  val 1.81  atom_stab 0.9163  mol_stab 0.2075  <- best  (7412s)
```

The `atom_stab` and `mol_stab` columns are new and they are the signal. Expect `val` and
`atom_stab` to sometimes disagree about which epoch is best — that is the point of defect 2, and
`atom_stab` wins.

There is also a new `inspect_checkpoint.py`: point it at any checkpoint and it samples on a
**fresh** seed and reports stability, validity and example molecules. Use it rather than the
training log when quoting a final number — the trainer selects the best of ~60 evaluations on one
fixed sample, so its reported best is optimistic by roughly one to two standard errors.
