"""Guidance fields: plug-in baseline and SMG, for both model families.

Notation follows SMG_PRIOR_WORK_AUDIT.md section 2 throughout:

    m     = E[x_1 | x_t]                    posterior mean (the endpoint proxy)
    J     = dm / dx_t                       denoiser Jacobian
    Sigma = Cov(x_1 | x_t)                  posterior covariance
    g     = grad f(m)                       property gradient at the mean
    H     = hess f(m)                       property Hessian at the mean
    c     = 1/2 tr(H Sigma)                 the nonlinear mean correction
    v_f   = g^T Sigma g                     property variance

    G_plug = (y - f(m)) / s^2                 * J^T g
    G_smg  = (y - f(m) - c) / (s^2 + v_f)     * J^T g

The ONLY term that is a candidate for novelty is c. It vanishes whenever f is
affine (H = 0), at which point G_smg reduces exactly to TMPD's published scalar
linear-observation formula. Everything else here -- the covariance, the
uncertainty denominator, the Jacobian identity, plug-in guidance -- is prior
work. See SMG_PRIOR_WORK_AUDIT.md sections 2.2 to 2.5.

Cost accounting, which the M-2 comparison depends on:

  * J^T (g + correction) is ONE VJP through the generator, i.e. one backward.
  * c and v_f both need Sigma acting on a vector. With the Tweedie identity
    Sigma = k * dm/dx_t, that is one JVP per probe vector. We use Hutchinson
    probes for tr(H Sigma) and a single exact JVP for Sigma g.
  * c and v_f are treated as CONSTANTS in the local derivative (stop-gradient),
    but are recomputed at every field evaluation, including both Heun stages.

Every routine takes and returns the (coords, feats) pair as a flat tuple so the
same code serves flow matching and diffusion; the family only changes how
(m, J, Sigma) are formed, which is the job of the Posterior classes.
"""
from __future__ import annotations

from dataclasses import dataclass

import torch


# --------------------------------------------------------------------------
# posterior mean / Jacobian / covariance, per model family
# --------------------------------------------------------------------------

@dataclass
class Posterior:
    """m, and the scalar k with Sigma = k * dm/dx_t.

    Flow matching, x_t = t x_1 + (1 - t) eps:
        m = x_t + (1 - t) v_theta,        k = (1 - t)^2 / t
    VP diffusion, x_tau = alpha x_0 + sigma eps:
        m = (x_tau - sigma eps_theta) / alpha,   k = sigma^2 / alpha

    Both are the standard second-order Tweedie relation for an independent
    Gaussian channel; they are NOT valid under an optimal-transport coupling.
    """

    mean_coords: torch.Tensor
    mean_feats: torch.Tensor
    k: float


def fm_posterior(net, coords, feats, mask, t):
    """Flow matching: m = x + (1-t) v, k = (1-t)^2 / t."""
    v_c, v_f = net(coords, feats, mask, t)
    tb = t.view(-1, 1, 1)
    m_c = coords + (1.0 - tb) * v_c
    m_f = feats + (1.0 - tb) * v_f
    tv = float(t.reshape(-1)[0])
    k = (1.0 - tv) ** 2 / max(tv, 1e-6)
    return Posterior(m_c, m_f, k)


def vp_posterior(net, coords, feats, mask, tau, alpha, sigma):
    """VP diffusion: m = (x - sigma eps) / alpha, k = sigma^2 / alpha."""
    e_c, e_f = net(coords, feats, mask, tau)
    a = alpha.view(-1, 1, 1)
    s = sigma.view(-1, 1, 1)
    m_c = (coords - s * e_c) / a
    m_f = (feats - s * e_f) / a
    av = float(alpha.reshape(-1)[0])
    sv = float(sigma.reshape(-1)[0])
    k = sv ** 2 / max(av, 1e-6)
    return Posterior(m_c, m_f, k)


# --------------------------------------------------------------------------
# the correction terms
# --------------------------------------------------------------------------

def _flat(*ts):
    return torch.cat([t.reshape(t.shape[0], -1) for t in ts], dim=1)


class Cost:
    """Every pass through the generator and the guide, so an arm's cost is
    measured rather than inferred from step counts. field_evals alone
    under-counts a guided step by roughly 3 forwards and a VJP."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.gen_fwd = self.gen_vjp = self.gen_jvp = 0
        self.guide_fwd = self.guide_bwd = self.guide_hvp = 0

    def as_dict(self):
        return dict(vars(self))

    def __repr__(self):
        return ("gen fwd=%d vjp=%d jvp=%d | guide fwd=%d bwd=%d hvp=%d"
                % (self.gen_fwd, self.gen_vjp, self.gen_jvp,
                   self.guide_fwd, self.guide_bwd, self.guide_hvp))


_NOCOST = Cost()


def property_derivs(f_net, m_c, m_f, mask, cost=_NOCOST):
    """f(m), and grad f(m) as a (coords, feats) pair. One backward."""
    m_c = m_c.detach().requires_grad_(True)
    m_f = m_f.detach().requires_grad_(True)
    val = f_net(m_c, m_f, mask)
    g_c, g_f = torch.autograd.grad(val.sum(), (m_c, m_f), create_graph=False)
    cost.guide_fwd += 1
    cost.guide_bwd += 1
    return val.detach(), g_c.detach(), g_f.detach()


def sigma_times_vector(post_fn, coords, feats, mask, vec_c, vec_f, k, cost=_NOCOST):
    """Sigma v = k * (dm/dx_t) v -- one JVP (forward mode), no graph retained."""
    def mfun(c, f):
        p = post_fn(c, f)
        return p.mean_coords, p.mean_feats

    _, (jv_c, jv_f) = torch.func.jvp(mfun, (coords, feats), (vec_c, vec_f))
    cost.gen_jvp += 1
    return k * jv_c.detach(), k * jv_f.detach()


def hutchinson_tr_H_Sigma(f_net, post_fn, coords, feats, mask, m_c, m_f, k,
                          n_probe, generator=None, cost=_NOCOST):
    """1/2 tr(H Sigma) by Hutchinson: E_z[ z^T H (Sigma z) ] with z Rademacher.

    H acts via one HVP at m; Sigma acts via one JVP through the generator. So
    each probe costs one JVP plus one HVP. Probes are drawn from `generator` so
    a trajectory can hold its probe set fixed, which the deterministic-solver
    comparison in M-4 requires.
    """
    total = torch.zeros(coords.shape[0], device=coords.device)
    msk = mask.unsqueeze(-1)
    for _ in range(n_probe):
        z_c = torch.randint(0, 2, coords.shape, generator=generator,
                            device=coords.device, dtype=coords.dtype)
        z_f = torch.randint(0, 2, feats.shape, generator=generator,
                            device=feats.device, dtype=feats.dtype)
        z_c = (z_c * 2.0 - 1.0) * msk
        z_f = (z_f * 2.0 - 1.0) * msk

        sz_c, sz_f = sigma_times_vector(post_fn, coords, feats, mask, z_c, z_f, k, cost)

        mc = m_c.detach().requires_grad_(True)
        mf = m_f.detach().requires_grad_(True)
        val = f_net(mc, mf, mask)
        gc, gf = torch.autograd.grad(val.sum(), (mc, mf), create_graph=True)
        cost.guide_fwd += 1
        cost.guide_hvp += 1
        # directional derivative of grad f along (sz) = H (sz).
        # An AFFINE property has a constant gradient: the scalar below then
        # carries no graph at all and differentiating it raises, so short
        # circuit to H = 0, which is the correct answer. allow_unused covers
        # the softer case where a graph exists but does not reach the inputs.
        scalar = (gc * sz_c).sum() + (gf * sz_f).sum()
        if not scalar.requires_grad:
            continue                       # H == 0, contributes nothing
        hv_c, hv_f = torch.autograd.grad(scalar, (mc, mf), allow_unused=True)
        if hv_c is None:
            hv_c = torch.zeros_like(mc)
        if hv_f is None:
            hv_f = torch.zeros_like(mf)
        total = total + ((z_c * hv_c).sum(dim=(1, 2))
                         + (z_f * hv_f).sum(dim=(1, 2))).detach()
    return 0.5 * total / n_probe


def _pullback(post_fn, coords, feats, w_c, w_f, cost=_NOCOST):
    """J^T (w_c, w_f) -- one VJP through the generator, shared by every arm.

    The weights are stop-gradient constants, which is why they can be folded in
    before the transpose rather than after.
    """
    c_in = coords.detach().requires_grad_(True)
    f_in = feats.detach().requires_grad_(True)
    p = post_fn(c_in, f_in)
    out = (p.mean_coords * w_c).sum() + (p.mean_feats * w_f).sum()
    G_c, G_f = torch.autograd.grad(out, (c_in, f_in))
    cost.gen_fwd += 1
    cost.gen_vjp += 1
    return G_c.detach(), G_f.detach()


def tfg_mc_weighted_grad(f_net, m_c, m_f, mask, y, s, n_mc, sigma,
                         generator=None, cost=_NOCOST):
    """TFG's Monte Carlo smoothing (methods/tfg.py), as a competitor to SMG.

    TFG perturbs the denoised estimate with isotropic Gaussian noise, evaluates
    the likelihood at each sample and averages in log space:

        L = logsumexp_k [ -(y - f(m + eps_k))^2 / 2 s^2 ] - log K,
        eps_k ~ N(0, sigma^2 I)

    which estimates log E_eps[ p(y | m + eps) ]. Differentiating,

        dL/dm = sum_k w_k * (y - f(m + eps_k))/s^2 * grad f(m + eps_k),
        w_k = softmax over k of the per-sample log-likelihood,

    so it returns a softmax-WEIGHTED average of per-sample plug-in gradients,
    rather than one gradient at the mean. Pulling it back through J is identical
    to every other arm.

    This attacks the same defect SMG does -- the property of the mean is not the
    mean of the property -- so it is the closest competitor we have, much closer
    than plain plug-in. What still differs:

      * the spread here is ISOTROPIC with sigma a tuned hyperparameter on a
        schedule; SMG uses the model's own posterior covariance
        Sigma_t = (sigma_t^2/alpha_t) d xhat_1/d x_t, which is anisotropic and
        read off the denoiser rather than tuned;
      * this is K-sample Monte Carlo (K = eps_bsz = 4 in their molecule script);
        SMG is deterministic at one JVP;
      * this averages the LIKELIHOOD; SMG corrects the property MOMENTS and then
        forms the likelihood.

    Cost: K guide forwards + K guide backwards, then the shared VJP.
    """
    K = max(int(n_mc), 1)
    msk = mask.unsqueeze(-1)
    lps, gcs, gfs = [], [], []
    for _ in range(K):
        e_c = torch.randn(m_c.shape, generator=generator, device=m_c.device,
                          dtype=m_c.dtype) * sigma * msk
        e_f = torch.randn(m_f.shape, generator=generator, device=m_f.device,
                          dtype=m_f.dtype) * sigma * msk
        mc = (m_c + e_c).detach().requires_grad_(True)
        mf = (m_f + e_f).detach().requires_grad_(True)
        val = f_net(mc, mf, mask)
        lp = -((y - val) ** 2) / (2.0 * s ** 2)
        gc, gf = torch.autograd.grad(lp.sum(), (mc, mf))
        cost.guide_fwd += 1
        cost.guide_bwd += 1
        lps.append(lp.detach())
        gcs.append(gc.detach())
        gfs.append(gf.detach())
    LP = torch.stack(lps)                       # [K, B]
    w = torch.softmax(LP, dim=0)                # [K, B]
    W = w.view(K, -1, 1, 1)
    G_c = (W * torch.stack(gcs)).sum(0)
    G_f = (W * torch.stack(gfs)).sum(0)
    return G_c, G_f, LP


# --------------------------------------------------------------------------
# the fields
# --------------------------------------------------------------------------

def guidance_field(f_net, post_fn, coords, feats, mask, y, s,
                   mode="plug", n_probe=1, generator=None, cost=_NOCOST,
                   n_mc=4, sigma_mc=0.1):
    """Return (G_coords, G_feats, diagnostics) in SCORE units.

    mode:
      "plug"        (y - f(m)) / s^2                      the baseline
      "smg_mean"    numerator gets -c, denominator s^2     ablation
      "smg_var"     denominator gets +v_f                  ablation
      "smg"         both -- the candidate
      "tfg_mc"      TFG's Monte Carlo smoothing -- the closest published
                    competitor, K samples at isotropic sigma_mc
    """
    with torch.no_grad():
        post = post_fn(coords, feats)
    cost.gen_fwd += 1
    m_c, m_f, k = post.mean_coords, post.mean_feats, post.k
    fval, g_c, g_f = property_derivs(f_net, m_c, m_f, mask, cost)

    if mode == "tfg_mc":
        w_c, w_f, LP = tfg_mc_weighted_grad(f_net, m_c, m_f, mask, y, s,
                                            n_mc, sigma_mc, generator, cost)
        G_c, G_f = _pullback(post_fn, coords, feats, w_c, w_f, cost)
        return G_c, G_f, {"f": fval, "c": torch.zeros_like(fval),
                          "v_f": torch.zeros_like(fval), "k": k,
                          "n_mc": n_mc, "sigma_mc": sigma_mc,
                          "mc_logp_spread": (LP.max(0).values - LP.min(0).values)}

    c_term = torch.zeros_like(fval)
    v_f = torch.zeros_like(fval)
    if mode in ("smg_mean", "smg"):
        c_term = hutchinson_tr_H_Sigma(f_net, post_fn, coords, feats, mask,
                                       m_c, m_f, k, n_probe, generator, cost)
    if mode in ("smg_var", "smg"):
        sg_c, sg_f = sigma_times_vector(post_fn, coords, feats, mask,
                                        g_c, g_f, k, cost)
        v_f = (g_c * sg_c).sum(dim=(1, 2)) + (g_f * sg_f).sum(dim=(1, 2))

    num = y - fval - c_term
    den = s ** 2 + v_f
    scale = (num / den).view(-1, 1, 1)

    G_c, G_f = _pullback(post_fn, coords, feats, scale * g_c, scale * g_f, cost)

    diag = {"f": fval, "c": c_term, "v_f": v_f, "k": k,
            "num": num, "den": den}
    return G_c.detach(), G_f.detach(), diag
