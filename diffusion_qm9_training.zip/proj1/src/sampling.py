"""ODE samplers -- Euler and Heun -- for both model families, with guidance.

Implements SMG_PRIOR_WORK_AUDIT.md section 3 exactly:

  Euler         x_{n+1} = x_n + h F(x_n, t_n)
  Heun (RK2)    k1 = F(x_n, t_n);  x~ = x_n + h k1;  k2 = F(x~, t_n + h)
                x_{n+1} = x_n + h/2 (k1 + k2)

with F the FULL guided field, re-evaluated (generator, posterior, f, g, H, c,
v_f, all schedules) at the predicted state in stage two. Holding the guidance
fixed across stages would be a different method.

Fields (section 3.1 / 3.2):

  flow matching   F = v_theta + w (1 - t) / t * G,           t: 0 -> 1, h > 0
  VP diffusion    F = -1/2 beta x - 1/2 beta (s_theta + G),   tau: 1 -> 0, h < 0

with G in score units from guidance.py and s_theta = -eps_theta / sigma.

GUIDANCE CLIP. The (1 - t)/t conversion factor is 19 at t = 0.05 and the raw
property gradient is several Debye per angstrom, so an unclipped correction
dwarfs the base velocity early in the trajectory and throws the sample off the
data manifold (measured: molecule stability 0.16 -> 0.02, a third of
trajectories non-finite). The correction is therefore capped at `clip` times
the base velocity norm, per sample. This is the velocity-relative trust region
of OSCAR (component A in our catalogue) -- prior work, adopted, not claimed.
`clip=None` disables it for the ablation that shows why it is needed.

Endpoint policy, declared once and used by every arm: integrate to the last
grid point, then jump to the posterior mean m there. Every generator, guide,
VJP and JVP pass is counted in `sampler.cost` so cost is measured, not inferred
from step counts.
"""
from __future__ import annotations

import torch

from diffusion import alpha_sigma, beta
from guidance import Cost, fm_posterior, guidance_field, vp_posterior
from models.egnn import zero_com


def _clip_to_velocity(G_c, G_f, v_c, v_f, mask, clip):
    """Scale (G_c, G_f) per sample so its norm is at most clip * |(v_c, v_f)|."""
    if clip is None:
        return G_c, G_f
    gn = torch.sqrt((G_c ** 2).sum((1, 2)) + (G_f ** 2).sum((1, 2)) + 1e-12)
    vn = torch.sqrt((v_c ** 2).sum((1, 2)) + (v_f ** 2).sum((1, 2)) + 1e-12)
    f = torch.clamp(clip * vn / gn, max=1.0).view(-1, 1, 1)
    return G_c * f, G_f * f


class _Base:
    def __init__(self, net, mask, f_net=None, y=None, s=1.0, mode="plug",
                 w=1.0, n_probe=1, probe_seed=0, clip=1.0,
                 n_mc=4, sigma_mc=0.1):
        self.net, self.mask = net, mask
        self.f_net, self.y, self.s, self.mode, self.w = f_net, y, s, mode, w
        self.n_probe, self.clip = n_probe, clip
        self.n_mc, self.sigma_mc = n_mc, sigma_mc
        self.cost = Cost()
        self.n_field = 0
        self.n_clipped = 0
        self.n_guided = 0
        self.probe_gen = torch.Generator(device=mask.device).manual_seed(probe_seed)
        self.last_diag = None

    def reset_counts(self):
        self.cost.reset()
        self.n_field = self.n_clipped = self.n_guided = 0

    def _guide(self, coords, feats, t, post_fn):
        G_c, G_f, diag = guidance_field(self.f_net, post_fn, coords, feats,
                                        self.mask, self.y, self.s, self.mode,
                                        self.n_probe, self.probe_gen, self.cost,
                                        self.n_mc, self.sigma_mc)
        self.last_diag = diag
        return zero_com(G_c, self.mask), G_f * self.mask.unsqueeze(-1)


class FlowSampler(_Base):
    def __init__(self, net, mask, t_min_guide=0.05, **kw):
        super().__init__(net, mask, **kw)
        self.t_min_guide = t_min_guide

    def time_grid(self, n_steps, span=None):
        a, b = (0.0, 1.0) if span is None else span
        return torch.linspace(a, b, n_steps + 1)

    def field(self, coords, feats, t_scalar):
        self.n_field += 1
        B = coords.shape[0]
        t = torch.full((B,), float(t_scalar), device=coords.device)
        with torch.no_grad():
            v_c, v_f = self.net(coords, feats, self.mask, t)
        self.cost.gen_fwd += 1
        if self.f_net is None or t_scalar < self.t_min_guide or t_scalar >= 1.0:
            return v_c, v_f

        self.n_guided += 1
        post_fn = lambda c, f: fm_posterior(self.net, c, f, self.mask, t)  # noqa: E731
        G_c, G_f = self._guide(coords, feats, t, post_fn)
        mult = self.w * (1.0 - t_scalar) / t_scalar
        G_c, G_f = mult * G_c, mult * G_f
        if self.clip is not None:
            gn = torch.sqrt((G_c ** 2).sum((1, 2)) + (G_f ** 2).sum((1, 2)))
            vn = torch.sqrt((v_c ** 2).sum((1, 2)) + (v_f ** 2).sum((1, 2)))
            self.n_clipped += int((gn > self.clip * vn).sum().item())
            G_c, G_f = _clip_to_velocity(G_c, G_f, v_c, v_f, self.mask, self.clip)
        return v_c + G_c, v_f + G_f

    @torch.no_grad()
    def terminal(self, coords, feats, t_scalar):
        return coords, feats            # t = 1: m = x


class VPSampler(_Base):
    def __init__(self, net, mask, tau_min=1e-3, **kw):
        super().__init__(net, mask, **kw)
        self.tau_min = tau_min

    def time_grid(self, n_steps, span=None):
        a, b = (1.0, self.tau_min) if span is None else span
        return torch.linspace(a, b, n_steps + 1)                  # decreasing

    def field(self, coords, feats, tau_scalar):
        self.n_field += 1
        B = coords.shape[0]
        tau = torch.full((B,), float(tau_scalar), device=coords.device)
        a, s = alpha_sigma(tau)
        b = beta(tau).view(-1, 1, 1)
        sb = s.view(-1, 1, 1)
        with torch.no_grad():
            e_c, e_f = self.net(coords, feats, self.mask, tau)
        self.cost.gen_fwd += 1
        score_c = -e_c / sb
        score_f = -e_f / sb
        base_c = -0.5 * b * coords - 0.5 * b * score_c
        base_f = -0.5 * b * feats - 0.5 * b * score_f
        if self.f_net is not None:
            self.n_guided += 1
            post_fn = lambda c, f: vp_posterior(self.net, c, f, self.mask, tau, a, s)  # noqa: E731
            G_c, G_f = self._guide(coords, feats, tau, post_fn)
            G_c, G_f = -0.5 * b * self.w * G_c, -0.5 * b * self.w * G_f
            if self.clip is not None:
                gn = torch.sqrt((G_c ** 2).sum((1, 2)) + (G_f ** 2).sum((1, 2)))
                vn = torch.sqrt((base_c ** 2).sum((1, 2)) + (base_f ** 2).sum((1, 2)))
                self.n_clipped += int((gn > self.clip * vn).sum().item())
                G_c, G_f = _clip_to_velocity(G_c, G_f, base_c, base_f, self.mask, self.clip)
            base_c, base_f = base_c + G_c, base_f + G_f
        m = self.mask.unsqueeze(-1)
        return zero_com(base_c, self.mask), base_f * m

    @torch.no_grad()
    def terminal(self, coords, feats, tau_scalar):
        B = coords.shape[0]
        tau = torch.full((B,), float(tau_scalar), device=coords.device)
        p = vp_posterior(self.net, coords, feats, self.mask, tau, *alpha_sigma(tau))
        self.cost.gen_fwd += 1
        return zero_com(p.mean_coords, self.mask), p.mean_feats * self.mask.unsqueeze(-1)


def integrate(sampler, coords, feats, n_steps, solver="euler", span=None,
              terminal=True):
    """Run the declared ODE. Returns (coords, feats, n_field_evals); the full
    cost breakdown is in sampler.cost afterwards.

    span=(a, b) integrates an interior interval; terminal=False skips the
    endpoint policy. Both exist for the same-field convergence check, which
    needs a smooth field away from the endpoints and the guidance switch-on."""
    sampler.reset_counts()
    ts = sampler.time_grid(n_steps, span)
    for i in range(n_steps):
        t0, t1 = float(ts[i]), float(ts[i + 1])
        h = t1 - t0
        k1_c, k1_f = sampler.field(coords, feats, t0)
        if solver == "euler":
            coords = coords + h * k1_c
            feats = feats + h * k1_f
        elif solver == "heun":
            xt_c = coords + h * k1_c
            xt_f = feats + h * k1_f
            k2_c, k2_f = sampler.field(xt_c, xt_f, t1)
            coords = coords + 0.5 * h * (k1_c + k2_c)
            feats = feats + 0.5 * h * (k1_f + k2_f)
        else:
            raise ValueError(solver)
    if terminal:
        coords, feats = sampler.terminal(coords, feats, float(ts[-1]))
    return coords, feats, sampler.n_field


def initial_noise(mask, n_types, generator=None):
    """x at t = 0 (flow) or tau = 1 (diffusion): N(0, I) on the zero-CoM
    subspace for coordinates, N(0, I) masked for atom types."""
    B, N = mask.shape
    c = torch.randn(B, N, 3, generator=generator, device=mask.device)
    f = torch.randn(B, N, n_types, generator=generator, device=mask.device)
    return zero_com(c, mask), f * mask.unsqueeze(-1)
