# Train the flow matching base model on QM9

**Package built 19 September 2026.** **This is the higher-priority package.** If you only have capacity for one, run this one.

Everything needed is in this folder except the ~250 MB raw dataset, which one command downloads.
You need a CUDA GPU; the rest is a normal PyTorch environment.

**Your time: about 15 minutes.** Then the machine runs unattended for roughly a day, resumable at
any point.

If you are using a coding assistant, point it at **`AGENT_BRIEF.md`** as well — it states the
invariants and failure modes compactly.

---

## What this is

A generative model over 3D molecules: atom coordinates and atom types, **no bond graph**. QM9,
133,885 molecules, up to 29 atoms from H/C/N/O/F. The network is an E(n)-equivariant graph
network, so rotating or translating a molecule leaves its prediction unchanged by construction.

Linear (rectified) flow matching. Generation time runs t: 0 (noise) -> 1 (data) with

    x_t = t * x_1 + (1 - t) * eps,        target velocity u = x_1 - eps

so the target is constant along each path and training is a plain regression onto x_1 - eps.

We need two such models — one flow matching, one diffusion — trained identically apart from the
objective, so the two families can be compared fairly.

---

## Setup

```bash
pip install torch --index-url https://download.pytorch.org/whl/cu128
pip install numpy rdkit
```

### Get the data

```bash
mkdir -p data && cd data
curl -L -o gdb9.tar.gz https://deepchemdata.s3.us-west-1.amazonaws.com/datasets/gdb9.tar.gz
tar xzf gdb9.tar.gz          # gives gdb9.sdf and gdb9.sdf.csv
cd ..
python proj1/scripts/prepare_qm9.py
```

About 11 seconds. **The printed counts must be exactly:**

```
kept 133885 molecules, skipped {'no_mol': 0, 'no_conf': 0, 'too_big': 0, 'bad_type': 0, 'no_props': 0}
split sizes: train_a=51527  train_b=51527  val=17748  test=13083
```

If they differ, stop and tell Henry. The seed is fixed at 20260917 precisely so that everyone's
split is identical; a different split makes the checkpoint unusable to us.

### Verify everything in one command

```bash
python verify_setup.py
```

Six checks, about two minutes: environment, data, 12 architecture tests, a 2-epoch smoke train,
sampler correctness, and **a measured seconds/epoch for your machine** with a projection to the
full run. It stops at the first failure with the command that fixes it, and on success prints the
exact training command.

**Do not start the real run until this exits 0.**

There is also `inspect_checkpoint.py`: point it at any checkpoint -- including a
mid-run `_last.pt` -- and it samples molecules, reports stability and validity, prints
example structures, and says whether the run looks healthy. Use it if something seems
off, instead of waiting to send a log.

---

## The real run

```bash
python -u proj1/scripts/train_fm.py --epochs 1500 --batch 256 \
    --hidden 256 --layers 8 --split train_a --tag fm --resume 2>&1 | tee fm.log
```

On our RTX 5080: ~30 s/epoch of pure training, ~44 s/epoch on the epochs that also run a
validation pass or the stability sampling. Over 1500 epochs that is roughly **13-18 hours**.
`verify_setup.py` measures the training rate on your hardware and prints the figure.

**Disk:** about 600 MB of checkpoints (the best model, the resume state and its backup,
plus a 30 MB snapshot every 100 epochs).

### If your machine has a time limit, or you want to stop and resume

```bash
# stops cleanly at 225 minutes rather than losing a partial epoch
python -u proj1/scripts/train_fm.py ... --max-minutes 225

# re-run the identical command to continue; optimiser, EMA and RNG state are restored
python -u proj1/scripts/train_fm.py ... --resume
```

A SLURM template is in `proj1/cluster/`, but it is tuned to our cluster's submit filter — treat
it as a reference rather than something to run directly.

---

## What to watch

**`atom_stab`, not the loss.** The loss keeps improving long after sample quality stops, and it
cannot see the ~0.1 Angstrom precision that decides whether a bond is recognised. So the trainer
samples 512 molecules every 25 epochs, measures the fraction of atoms with correct inferred
valency, and selects the checkpoint on that.

A molecule counts as stable only if **every** atom is, so over ~18 atoms the metric compounds
sharply:

| atom stability | molecule stability |
|---|---|
| 0.88 | 0.10 |
| 0.92 | 0.22 |
| 0.95 | 0.40 |
| 0.97 | 0.58 |
| 0.987 (published EDM) | 0.79 |

**The 0.987 row is E(3)-EDM's *unconditional* figure from a model trained on ~100k
molecules.** This package trains on 51,527, so it is a reference point for how the metric
compounds, **not a target**. `SPLIT_PROTOCOL.md` explains why, and retracts an earlier
draft that set 0.97 as the goal on the strength of that number.

Going from 0.92 to 0.95 nearly doubles molecule stability. Small gains matter.

### Reading a log line

```
ep  250  train 1.81 (c 1.65 f 0.16)  val 1.81  atom_stab 0.9163  mol_stab 0.2075  <- best  (7412s)
```

`c` and `f` are the coordinate and atom-type parts of the loss. Coordinates are the slow half and
are what bond inference depends on. `<- best` means this checkpoint was saved.
The trailing `(7412s)` is **cumulative** seconds since this process started, not
the time for that epoch -- subtract consecutive lines to get a per-epoch figure,
and note it resets to 0 on every `--resume`.

### Loss scale for this objective

The target u = x_1 - eps has variance Var(x_1) + 1 per dimension. Predicting zero
gives ~2.95 on coordinates and ~1.20 on atom types. Note the optimal predictor cannot reach
zero either -- at low t the target contains unknowable noise -- so **the loss is not a quality
measure.** Ours plateaus near 1.81 while sample quality keeps improving.

### Our reference trajectory

**We deliberately do not give you a curve to match.** Our only long run used a
different data split (103,054 molecules; this package trains on 51,527), so every number from it
is unreproducible here and comparing against it would mislead you.

What we can give you is epoch 1 under **exactly the shipped configuration**, measured:

| epoch | train | coord | feat | val | atom_stab |
|---|---|---|---|---|---|
| 1 | **2.48007** | 2.13361 | 0.34647 | 2.27283 | 0.2357 |

If your epoch 1 is close to that, the setup is right. After that, judge by whether `atom_stab`
is rising, not by any particular value.

**Please send a short note at roughly epoch 300** with the recent lines. If the trajectory is off
we would much rather know then than after a day of compute.

---

## Please don't change

These are fixed upstream so the pieces compose. If one looks wrong, tell Henry rather than fixing
it locally — a silent local fix that diverges from the other model family is worse than a bug we
both know about.

- the `prepare_qm9.py` seed
- **`--split train_a`** (51,527 molecules). The generator must not see `train_b`: that
  half trains the evaluator. **`SPLIT_PROTOCOL.md` has the reasoning and the evidence.**
- `proj1/src/models/egnn.py`
- `--split train_a`, `--hidden 256`, `--layers 8`, `--batch 256`

---

## What to send back

1. `proj1/checkpoints/fm.pt` — the selected model (holds both raw and EMA weights)
2. `proj1/checkpoints/fm_history.json` — loss and stability curves
3. the full log
4. one line: epoch reached, best `atom_stab`, best `mol_stab`, seconds/epoch

A Drive or Dropbox link is fine. `fm_last.pt` is only resume state — no need to send it unless
you want us to be able to continue the run.

---

## Gotchas we already hit

- **Relaunching used to overwrite a better checkpoint.** Fixed: `best` seeds from whatever is on
  disk, so a restart can only improve it. `--fresh` overrides if you really want to start over.
- **`CUDA_VISIBLE_DEVICES=""` does not hide the GPU from PyTorch on Windows.** Use `--device cpu`.
- **`nan` on the first batch** means `egnn.py` was modified — there is a `sqrt(0)` whose gradient
  is infinite at coincident atoms. Check 12 in the symmetry test exists for exactly this.
- **`val` improving while `atom_stab` is flat** is normal. Trust `atom_stab`.

Questions to Henry — asking costs a message, guessing can cost a day.
